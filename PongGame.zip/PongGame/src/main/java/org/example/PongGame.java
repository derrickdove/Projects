package org.example;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;

public class PongGame {

    public static void main(String[] args) {

        GameFrame frame = new GameFrame();



    }

}
